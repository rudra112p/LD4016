<?php
include 'db_connect.php'; // Ensure this file includes the correct database connection details

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];

    // Prepare the SQL statement to delete the user
    $sql = "DELETE FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);

    // Execute the statement and check for success
    if ($stmt->execute()) {
        echo "success"; // Respond with success
    } else {
        echo "error"; // Respond with error
    }

    $stmt->close();
    $conn->close();
}
?>
