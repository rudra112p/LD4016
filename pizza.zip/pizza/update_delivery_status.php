<?php
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delivery_id']) && isset($_POST['status'])) {
    $delivery_id = $_POST['delivery_id'];
    $status = $_POST['status'];

    // Update the delivery status in the database
    $sql = "UPDATE delivery_info SET delivery_status = ? WHERE delivery_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $status, $delivery_id);
    if ($stmt->execute()) {
        // Retrieve the updated delivery information
        $sql = "SELECT delivery_id, delivery_status, delivery_address, delivery_time FROM delivery_info WHERE delivery_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $delivery_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            echo "Delivery ID {$row['delivery_id']} - Status: {$row['delivery_status']} <br>
                  <strong>Address:</strong> {$row['delivery_address']} <br>
                  <strong>Time:</strong> {$row['delivery_time']} <br>
                  <button onclick='updateDeliveryStatus({$row['delivery_id']}, \"Complete\")'>Mark Complete</button>
                  <button onclick='updateDeliveryStatus({$row['delivery_id']}, \"Cancelled\")'>Cancel</button>";
        } else {
            echo "Error fetching updated delivery information.";
        }
    } else {
        echo "Error updating delivery status.";
    }
    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request.";
}
?>
