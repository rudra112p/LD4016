<?php
include 'db_connect.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the credentials are for the admin
    if ($username == "admin" && $password == "1234") {
        // Directly set the admin session and redirect to admin dashboard
        $_SESSION['user_id'] = "admin";
        $_SESSION['username'] = "admin";
        header("Location: admin.php"); // Redirect to an admin-specific dashboard
        exit();
    }

    // Regular user login process
    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['username'] = $row['username'];
            header("Location: index.html"); // Redirect to a general user dashboard or homepage
            exit();
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "No user found with that username.";
    }

    $stmt->close();
    $conn->close();
}
?>
