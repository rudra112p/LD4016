<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin.css">

    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .admin-section {
            margin-bottom: 40px;
        }

        ul {
            list-style-type: none;
        }

        li {
            margin: 5px 0;
        }

        button {
            margin-left: 10px;
        }
    </style>
</head>

<body>
    <h1>Admin Dashboard</h1>

    <!-- Users Management Section -->
    <div class="admin-section" id="users-management">
        <h2>Manage Users</h2>
        <ul id="users-list">
            <?php
            include 'db_connect.php'; // Ensure your DB connection settings are correct
            $sql = "SELECT user_id, username FROM users";
            $result = $conn->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<li id='user-{$row['user_id']}'>{$row['username']} <button onclick='deleteUser({$row['user_id']})'>Delete</button></li>";
            }
            ?>
        </ul>
    </div>

    <div class="admin-section" id="pizza-management">
        <h2>Manage Pizzas</h2>
        <ul id="pizzas-list">
            <?php
            $sql = "SELECT pizza_id, name, description, price FROM pizzas";
            $result = $conn->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<li id='pizza-{$row['pizza_id']}'>
                    <span><strong>{$row['name']}</strong> - {$row['description']} - \${$row['price']}</span>
                    <button onclick='editPizza({$row['pizza_id']}, \"{$row['name']}\", \"{$row['description']}\", {$row['price']})'>Edit</button>
                    <button onclick='deletePizza({$row['pizza_id']})'>Delete</button>
                  </li>";
            }
            ?>
        </ul>
    </div>

    <!-- Hidden form to edit pizza details -->
    <div id="edit-pizza-form" style="display:none;">
        <h2>Edit Pizza</h2>
        <form id="edit-pizza" method="post" onsubmit="submitEditPizza(event)">
            <input type="hidden" id="edit-pizza-id">
            <label for="edit-pizza-name">Name:</label>
            <input type="text" id="edit-pizza-name" name="name" required><br>
            <label for="edit-pizza-description">Description:</label>
            <textarea id="edit-pizza-description" name="description" required></textarea><br>
            <label for="edit-pizza-price">Price:</label>
            <input type="number" id="edit-pizza-price" name="price" step="0.01" required><br>
            <button type="submit">Save Changes</button>
            <button type="button" onclick="cancelEditPizza()">Cancel</button>
        </form>
    </div>

    <!-- Delivery Management Section -->
    <div class="admin-section" id="delivery-management">
        <h2>Manage Deliveries</h2>
        <ul id="deliveries-list">
            <?php
            $sql = "SELECT delivery_id, delivery_status, delivery_address, delivery_time FROM delivery_info";
            $result = $conn->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<li id='delivery-{$row['delivery_id']}'>
                        <strong>Delivery ID:</strong> {$row['delivery_id']} <br>
                        <strong>Status:</strong> {$row['delivery_status']} <br>
                        <strong>Address:</strong> {$row['delivery_address']} <br>
                        <strong>Time:</strong> {$row['delivery_time']} <br>
                        <button onclick='updateDeliveryStatus({$row['delivery_id']}, \"Complete\")'>Mark Complete</button>
                        <button onclick='updateDeliveryStatus({$row['delivery_id']}, \"Cancelled\")'>Cancel</button>
                      </li>";
            }
            ?>
        </ul>
    </div>

    <script>
        function editPizza(pizzaId, name, description, price) {
            // Show the edit form and fill it with the current pizza details
            document.getElementById('edit-pizza-id').value = pizzaId;
            document.getElementById('edit-pizza-name').value = name;
            document.getElementById('edit-pizza-description').value = description;
            document.getElementById('edit-pizza-price').value = price;

            document.getElementById('edit-pizza-form').style.display = 'block';
        }

        function cancelEditPizza() {
            // Hide the edit form
            document.getElementById('edit-pizza-form').style.display = 'none';
        }

        function submitEditPizza(event) {
            event.preventDefault();

            var pizzaId = document.getElementById('edit-pizza-id').value;
            var name = document.getElementById('edit-pizza-name').value;
            var description = document.getElementById('edit-pizza-description').value;
            var price = document.getElementById('edit-pizza-price').value;

            var xhr = new XMLHttpRequest();
            xhr.open("POST", "edit_pizza.php", true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhr.onload = function() {
                if (xhr.status == 200) {
                    // Update the pizza details in the DOM
                    document.querySelector('#pizza-' + pizzaId + ' span').innerHTML = '<strong>' + name + '</strong> - ' + description + ' - $' + parseFloat(price).toFixed(2);
                    alert('Pizza updated successfully.');
                    cancelEditPizza(); // Hide the form after editing
                } else {
                    alert('Failed to update pizza.');
                }
            };
            xhr.send("pizza_id=" + pizzaId + "&name=" + encodeURIComponent(name) + "&description=" + encodeURIComponent(description) + "&price=" + price);
        }

        function deleteUser(userId) {
            if (confirm('Are you sure you want to delete this user?')) {
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "delete_user.php", true);
                xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xhr.onload = function() {
                    if (xhr.status == 200) {
                        document.getElementById('user-' + userId).remove();
                        alert('User deleted successfully.');
                    } else {
                        alert('Failed to delete user.');
                    }
                };
                xhr.send("user_id=" + userId);
            }
        }

        function deletePizza(pizzaId) {
            if (confirm('Are you sure you want to delete this pizza?')) {
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "delete_pizza.php", true);
                xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xhr.onload = function() {
                    if (xhr.status == 200) {
                        document.getElementById('pizza-' + pizzaId).remove();
                        alert('Pizza deleted successfully.');
                    } else {
                        alert('Failed to delete pizza.');
                    }
                };
                xhr.send("pizza_id=" + pizzaId);
            }
        }

        function updateDeliveryStatus(deliveryId, status) {
            if (confirm('Are you sure you want to update the delivery status?')) {
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "update_delivery_status.php", true);
                xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xhr.onload = function() {
                    if (xhr.status == 200) {
                        document.getElementById('delivery-' + deliveryId).innerHTML = xhr.responseText;
                        alert('Delivery status updated successfully.');
                    } else {
                        alert('Failed to update delivery status.');
                    }
                };
                xhr.send("delivery_id=" + deliveryId + "&status=" + status);
            }
        }
    </script>
</body>

</html>