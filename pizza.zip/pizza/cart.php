<?php
session_start(); // Ensure session start at the beginning to access session variables

$host = 'localhost';  // Your host name
$user = 'root';       // Your database username
$password = '';       // Your database password
$database = 'pizza_delivery';  // Your database name

// Create database connection
$conn = new mysqli($host, $user, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure the user is logged in and a user_id is set
if (!isset($_SESSION['user_id'])) {
    echo "<p>Please <a href='login.php'>login</a> to view your cart.</p>";
    exit(); // Stop further execution if user is not logged in
}

$user_id = $_SESSION['user_id'];

// Fetch orders from the database for the logged-in user
$sql = "SELECT orders.order_id, pizzas.name, orders.quantity, orders.total_price 
        FROM orders 
        JOIN pizzas ON orders.pizza_id = pizzas.pizza_id
        WHERE orders.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Calculate total price
$total_price = 0;
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $total_price += $row['total_price'];
    }
    // Reset the result pointer back to the beginning
    $result->data_seek(0);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to your CSS file -->
</head>
<body>
    <div class="cart-container">
        <h1>Your Cart</h1>

        <div class="cart-items">
            <?php if ($result->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Pizza Name</th>
                            <th>Quantity</th>
                            <th>Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['name']; ?></td>
                                <td><?php echo $row['quantity']; ?></td>
                                <td>$<?php echo number_format($row['total_price'], 2); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

                <div class="cart-total">
                    <h2>Total: $<?php echo number_format($total_price, 2); ?></h2>
                </div>

                <!-- Payment Button -->
                <div class="payment-button-container">
                    <a href="payment.php" class="payment-button">Proceed to Payment</a>
                </div>
            <?php else: ?>
                <p>Your cart is empty. <a href="menu.php">Go back to the menu</a> to add items.</p>
            <?php endif; ?>
        </div>
    </div>
</body>

    <style>
        .cart-container {
            width: 80%;
            margin: 0 auto;
            text-align: center;
            padding: 20px;
            background-color: #f4f4f4;
            border-radius: 8px;
        }

        .cart-items table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .cart-items table th,
        .cart-items table td {
            padding: 15px;
            border-bottom: 1px solid #ddd;
        }

        .cart-items table th {
            background-color: #e63946;
            color: #fff;
            font-weight: bold;
        }

        .cart-total {
            margin: 20px 0;
            font-size: 24px;
            font-weight: bold;
        }

        .payment-button-container {
            margin-top: 20px;
        }

        .payment-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #e63946;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        .payment-button:hover {
            background-color: #d62828;
        }
    </style>
</body>
</html>

<?php
$conn->close();
?>
