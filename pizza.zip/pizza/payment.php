<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="payment-container">
        <h1>Payment and Delivery Information</h1>
        <form action="delivery.php" method="post">
            <div class="form-group">
                <label for="cardNumber">Card Number:</label>
                <input type="text" id="cardNumber" name="cardNumber" placeholder="Enter your card number" required>
            </div>
            <div class="form-group">
                <label for="cardExpiry">Expiration Date (MM/YY):</label>
                <input type="text" id="cardExpiry" name="cardExpiry" placeholder="MM/YY" required>
            </div>
            <div class="form-group">
                <label for="cardCVC">CVC:</label>
                <input type="text" id="cardCVC" name="cardCVC" placeholder="CVC" required>
            </div>
            <div class="form-group">
                <label for="deliveryAddress">Delivery Address:</label>
                <input type="text" id="deliveryAddress" name="deliveryAddress" placeholder="Enter delivery address" required>
            </div>
            <button type="submit">Submit Payment</button>
        </form>
    </div>
</body>
</html>


    <style>
        .payment-container {
            width: 300px;
            margin: auto;
            padding: 20px;
            background: #f1f1f1;
            border-radius: 8px;
        }
        .form-group {
            margin-bottom: 10px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</body>
</html>
