<?php
session_start(); // Start the session to handle user login status

$host = 'localhost';  // Your host name
$user = 'root';       // Your database username
$password = '';       // Your database password
$database = 'pizza_delivery';  // Your database name

// Create database connection
$conn = new mysqli($host, $user, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission for orders
if (isset($_POST['order']) && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $pizza_id = $_POST['pizza_id'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'] * $quantity;  // Calculate total price based on quantity and unit price

    $insertSql = "INSERT INTO orders (user_id, pizza_id, quantity, total_price) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($insertSql);
    $stmt->bind_param("iiid", $user_id, $pizza_id, $quantity, $price);
    if ($stmt->execute()) {
        echo "<p>Order added successfully.</p>";
    } else {
        echo "<p>Error: " . $stmt->error . "</p>";
    }
    $stmt->close();
}

// Fetch pizzas from the database
$sql = "SELECT pizza_id, name, description, price, image_url FROM pizzas";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pizza Menu</title>
    <link rel="stylesheet" href="styles.css"> <!-- Ensure this link is correct -->
</head>

<body>
    <!-- Navigation Bar -->
    <nav>
        <div class="logo">Pizza Delight</div>
        <ul>
        <li><a href="index.html">Home</a></li>
            <li><a href="menu.php">Menu</a></li>
            <li><a href="login.html">Login</a></li>
        </ul>
    </nav>
    <h1>Pizza Menu</h1>
    <div class="menu-items">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="menu-item">
                    <img src="<?php echo $row['image_url']; ?>" alt="<?php echo $row['name']; ?>">
                    <h2><?php echo $row['name']; ?></h2>
                    <p><?php echo $row['description']; ?></p>
                    <p>Price: $<?php echo number_format($row['price'], 2); ?></p>

                    <!-- Order Form -->
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <form action="menu.php" method="post">
                            <input type="hidden" name="pizza_id" value="<?php echo $row['pizza_id']; ?>">
                            <input type="hidden" name="price" value="<?php echo $row['price']; ?>">
                            <input type="number" name="quantity" value="1" min="1">
                            <button type="submit" name="order">Add to Cart</button>
                        </form>
                    <?php else: ?>
                        <p><a href="login.html">Log in</a> to order.</p>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No pizzas available.</p>
        <?php endif; ?>
    </div>
    <!-- Go to Cart Button -->
    <div class="cart-button-container">
        <a href="cart.php" class="cart-button">Go to Cart</a>
    </div>
    <footer>
        <p>&copy; 2024 Pizza Delight. All Rights Reserved.</p>
    </footer>
</body>

<style>
    .menu-container {
        width: 80%;
        margin: 0 auto;
        text-align: center;
        padding: 20px;
        background-color: #f4f4f4;
        border-radius: 8px;
    }

    .cart-button-container {
        margin: 20px 0;
        text-align: right;
    }

    .cart-button {
        display: inline-block;
        padding: 10px 20px;
        background-color: #e63946;
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
        transition: background-color 0.3s ease;
    }

    .cart-button:hover {
        background-color: #d62828;
    }

    .menu-items {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
    }

    .menu-item {
        background: #fff;
        padding: 20px;
        margin: 15px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        text-align: left;
        width: calc(33% - 40px);
        /* Adjust this value as needed */
    }

    .menu-item img {
        width: 100%;
        border-radius: 8px;
    }

    .menu-item h2 {
        font-size: 24px;
        margin-top: 15px;
        color: black;
    }

    .menu-item p {
        margin: 10px 0;
        color: black;

    }

    .price {
        font-size: 18px;
        font-weight: bold;
        color: #e63946;
    }

    .order-form {
        margin-top: 10px;
    }

    .order-form label {
        margin-right: 10px;
        font-weight: bold;
    }

    .order-form input[type="number"] {
        width: 50px;
        text-align: center;
        margin-right: 10px;
    }

    .order-form button {
        background-color: #e63946;
        color: #fff;
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        cursor: pointer;
    }

    .order-form button:hover {
        background-color: #d62828;
    }

    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background: url('https://images.unsplash.com/photo-1559183533-ee5f4826d3db?q=80&w=1427&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D') no-repeat center center fixed;
        background-size: cover;
        color: #fff;
        /* Make text white to contrast with the background */
    }

    nav {
        background-color: rgba(0, 0, 0, 0.7);
        /* Semi-transparent background for the navbar */
        overflow: hidden;
        padding: 10px 20px;
    }

    nav .logo {
        float: left;
        color: #fff;
        font-size: 24px;
        font-weight: bold;
    }

    nav ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        float: right;
    }

    nav ul li {
        display: inline;
        margin-left: 20px;
    }

    nav ul li a {
        color: #fff;
        text-decoration: none;
        padding: 8px 16px;
        border-radius: 4px;
        transition: background-color 0.3s;
    }

    nav ul li a:hover {
        background-color: #575757;
    }
</style>
</body>

</html>

<?php
$conn->close();
?>