<?php
session_start();
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'pizza_delivery';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Assuming user_id and order_id are appropriately managed
$user_id = $_SESSION['user_id'] ?? 0; // Ensure the user is logged in and the user_id is stored in the session
$order_id = rand(1000, 9999);  // Simulated order ID for demonstration

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cardNumber = $_POST['cardNumber']; // Not stored, for demonstration only
    $deliveryAddress = $_POST['deliveryAddress'];

    // Insert delivery information into the database
    $sql = "INSERT INTO delivery_info (delivery_address, delivery_status, delivery_time) VALUES (?, 'Processing', NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s",  $deliveryAddress);
    if ($stmt->execute()) {
        // Prepare to show success message and redirect
        echo "<script>
                alert('Payment successful!');
                setTimeout(function() {
                    window.location.href = 'index.html'; // Redirect to the home page
                }, 3000); // Redirect after 3 seconds
              </script>";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "<p>Invalid access. No data submitted.</p>";
}

$conn->close();
?>
